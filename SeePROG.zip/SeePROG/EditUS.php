<?php 
include_once "DB.php";
$id = $_POST['id'];
$name  = $_POST['name'];
$pass  = $_POST['pass'];
$phone = $_POST['phone'];

$query = mysqli_query($conn , "INSERT INTO `edit`(`name`,`pass`,`phone`)VALUES('$name','$pass','$phone')");
$query2 = mysqli_query($conn , "UPDATE `users` SET `name`='$name',`password`='$pass',`phone`='$phone' WHERE `id`='$id'");

header('location:tables.php');


