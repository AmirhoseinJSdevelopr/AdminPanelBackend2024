function clicks(){
    alert('lopeto');
}