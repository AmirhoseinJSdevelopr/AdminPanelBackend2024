<?php
session_start(); 
$password = $_POST['password'];
$phone = $_POST['phone'];
include_once "DB.php";

if(!empty($password) && !empty($phone)){
    $query = mysqli_query($conn, "SELECT * FROM `users`");
    $item = [];
    $item2 = [];    


    // break;
    
    
    while($item = mysqli_fetch_assoc($query)){
       
        if($password == $item['password'] && $phone == $item['phone']){
            
            
            $_SESSION['yes'] = "ورود با موفقیت انجام شد";
            $query2 = mysqli_query($conn, "INSERT INTO `into`(`password`,`phone`)VALUES('$password','$phone')");
            header('location:logout.php');
            break;
        }

        else{
            $const = mysqli_query($conn , "SELECT * FROM `admin`");
    
            while($item2 = mysqli_fetch_assoc($const)){
                if ($password == $item2['password'] && $phone == $item2['phone']) {
                    header('location:index.php');
                }
                else{

                    $_SESSION['warning'] = "چنین کاربری در سیستم موجود نمی باشد";
                    header('location:logout.php');
                }
            }

        }
    }


}
else{
    $_SESSION['warning'] = "چنین کاربری در سیستم موجود نمی باشد";
    header('location:logout.php');



}



?>