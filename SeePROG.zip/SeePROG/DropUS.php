<?php
include_once "DB.php";
$id = $_POST['id'];
$tb = $_POST['tb'];
$sorth = $_POST['src'];

$query2 = mysqli_query($conn, "INSERT INTO `softdelets`(`id`) VALUES ('$id')");


$query = mysqli_query($conn , "DELETE FROM `$tb` WHERE `id` = '$id'");
header('location:'."$sorth");


