<?php 
session_start();
$name = $_POST['name'];
$pass = $_POST['password'];
$phone = $_POST['phone'];
$chache = $_POST['local'];
$main = $_POST['key'];


include_once "DB.php";



if (!empty($name) && !empty($pass) && !empty($phone)) {

$query = mysqli_query($conn , "INSERT INTO `users`(`name`,`phone`,`password`)VALUES('$name','$pass','$phone')");

$_SESSION['ok'] = '.ثبت نام شما با موفقیت کامل انجام شد';



header('location:login.php');

}
else{
    header('location:login.php');
    $_SESSION['error'] = "لطفا مقادیر را پر کنید";
    
}
?>
